"""
실측 혼합 데이터 검증
=====================
SMPS 3종이 동시에 켜지고 꺼지는 실측 세션에서 세 가지 순방향 모델을 비교한다.

    fix : 고정 서명 (기존 방식) + 배경을 상수 벡터로
    sp  : s(p) 곡선 + 배경을 상수 벡터로
    bg  : s(p) 곡선 + 배경도 s(p) 곡선   <- 권장

분해는 전력 격자에서 최근접 탐색으로 푼다. 학습 모델의 성능을 재는 것이
아니라 **순방향 모델의 품질**을 재는 것이 목적이므로, 추정기는 단순할수록
비교가 깨끗하다.

채점 지표는 두 가지만 쓴다. 둘 다 측정값과 직접 비교하므로 라벨 오류에
오염되지 않는다.

    1) 총전력 재현 MAE   : 추정 합 vs 측정 p_w
    2) 균형정확도         : (TPR+TNR)/2, 구간 on/off 기준

이벤트 ΔP 는 쓰지 않는다. 이유는 README §6.4 참조.
"""
import json
import numpy as np
import pandas as pd
from sp_model import SPModel

U    = '/mnt/user-data/uploads/'
IH   = ['ih%d'  % h for h in range(1, 16)]
DEG  = ['ihdeg%d'% h for h in range(1, 16)]
DEVS = ['laptop_charger', 'beam_projector', 'minipc']
NAME = {'fix': '고정 서명', 'sp': 's(p)', 'bg': 's(p)+배경'}
HI   = {'laptop_charger': 75., 'beam_projector': 55., 'minipc': 34., 'background': 13.}
GRID = {'laptop_charger': np.r_[0, np.arange(14, 76, 2.)],
        'beam_projector': np.r_[0, np.arange(20, 56, 2.)],
        'minipc':         np.r_[0, np.arange(5, 35, 1.)],
        'background':     np.arange(2.5, 10.5, 0.5)}

M = SPModel.load('sp_curves_v2.npz')
FIX = {a: M[a].signature(float(np.mean(M[a].P))) for a in DEVS}
KF  = {a: float(np.mean(M[a].k))   for a in DEVS}
PHF = {a: float(np.mean(M[a].ph1)) for a in DEVS}


def load(path):
    d = pd.read_csv(path)
    A = d[IH].values.astype(float)
    return dict(C=A * np.exp(1j * np.deg2rad(d[DEG].values.astype(float))),
                P=d.p_w.values.astype(float), V=d.vrms.values.astype(float),
                T=d.t_s.values.astype(float),
                good=(d.pll_locked.values == 1) & (d.over_range.values == 0))


def states(gt, T):
    out, anyon = {}, np.zeros(len(T), bool)
    for a, v in gt['intervals'].items():
        m = np.zeros(len(T), bool)
        for lo, hi in v['on']:
            m[(T >= lo) & (T <= hi)] = True
        for lo, hi in v['uncertain']:
            anyon[(T >= lo) & (T <= hi)] = True
        out[a] = m; anyon |= m
    return out, ~anyon


def run(path, gt, K=60):
    """K 사이클 데시메이션 후 세 모드로 분해"""
    D = load(path)
    st, offm = states(gt, D['T'])
    om   = offm & D['good']
    BASE = D['C'][om].mean(0)
    BP   = float(D['P'][om].mean())
    VREF = float(D['V'][D['good']].mean())

    n  = len(D['T']) // K * K
    Cd = D['C'][:n].reshape(-1, K, 15).mean(1)
    Pd = D['P'][:n].reshape(-1, K).mean(1)
    Td = D['T'][:n].reshape(-1, K).mean(1)
    Gd = D['good'][:n].reshape(-1, K).mean(1) > 0.9
    Od = np.stack([st[a][:n].reshape(-1, K).mean(1) > 0.5 for a in DEVS], 1)
    Y  = np.c_[Cd.real, Cd.imag]

    out = {}
    for mode in ('fix', 'sp', 'bg'):
        cols = []
        for a in DEVS:
            g = GRID[a]; L = np.zeros((len(g), 15), complex)
            for i, p in enumerate(g):
                if p > 0.2:
                    L[i] = (M[a].current(p, VREF) if mode != 'fix'
                            else FIX[a] * (KF[a] * p / VREF) * np.exp(1j * PHF[a]))
            cols.append((g, L))
        if mode == 'bg':
            g = GRID['background']
            cols.append((g, np.array([M['background'].current(p, VREF) for p in g])))
        else:
            cols.append((np.array([BP]), BASE[None, :]))

        S = (cols[0][1][:, None, None, None, :] + cols[1][1][None, :, None, None, :]
           + cols[2][1][None, None, :, None, :] + cols[3][1][None, None, None, :, :]
             ).reshape(-1, 15)
        Sr  = np.c_[S.real, S.imag]
        Sn  = (Sr * Sr).sum(1)
        idx = np.array(np.meshgrid(*[c[0] for c in cols], indexing='ij')).reshape(4, -1).T

        est = np.zeros((len(Cd), 4))
        for i in range(len(Cd)):
            if not Gd[i]:
                est[i] = est[i - 1] if i else 0; continue
            est[i] = idx[np.argmin(Sn - 2 * (Sr @ Y[i]))]
        out[mode] = est
    return dict(Td=Td, Pd=Pd, Od=Od, Gd=Gd, BP=BP, est=out)


def score(r, label):
    print('=' * 68)
    print(label)
    print('%-12s %11s %12s %10s %10s'
          % ('method', '총전력MAE', '균형정확도', 'LC bal', 'MP bal'))
    for m in ('fix', 'sp', 'bg'):
        e = r['est'][m]
        mae = np.abs(e[:, :3].sum(1) + e[:, 3] - r['Pd'])[r['Gd']].mean()
        b = []
        for k in range(3):
            p = e[:, k] > 3.0; g = r['Od'][:, k]; G = r['Gd']
            tp = (p & g & G).sum(); fp = (p & ~g & G).sum()
            fn = (~p & g & G).sum(); tn = (~p & ~g & G).sum()
            b.append(0.5 * (tp / max(tp + fn, 1) + tn / max(tn + fp, 1)))
        print('%-12s %10.2fW %12.3f %10.3f %10.3f'
              % (NAME[m], mae, np.mean(b), b[0], b[2]))
    print()


if __name__ == '__main__':
    GT = json.load(open(U + '1788423985364_real_events_refined.json'))['files']
    for tag, path, note in [
        ('test_8',  U + 'test_8.csv',                 'test_8  (배경 곡선 in-sample)'),
        ('test_13', U + '1788425064075_test_13.csv',  'test_13 (완전 홀드아웃)')]:
        score(run(path, GT[tag]), note)
