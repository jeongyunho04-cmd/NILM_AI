"""s(p) 모델 검증 — 재현 오차, 판별력 비교, 혼합 분리 테스트"""
import numpy as np
from sp_model import SPModel, mix
from fit_sp import load_clean, extract

U = '/mnt/user-data/uploads/'
FILES = {
 'laptop_charger': [U+'1788419936215_laptop_charger_1.csv', U+'1788419936214_laptop_charger_3_fixed.csv'],
 'minipc':         [U+'1788419942496_minipc_2.csv', U+'1788419942496_minipc_3.csv'],
 'beam_projector': [U+'1788419611621_beam_projector_1.csv', U+'1788419611621_beam_projector_2.csv'],
}

def ri(s):
    return np.r_[s[1:].real, s[1:].imag]

def ang(a, b):
    c = abs(a @ b) / np.linalg.norm(a) / np.linalg.norm(b)
    return np.degrees(np.arccos(np.clip(c, -1, 1)))

M = SPModel.load('sp_curves.npz')
rng = np.random.default_rng(0)

print('=== 1. 재현 오차 (측정 프레임 vs 모델 예측 서명) ===')
print('%-16s %8s %10s %10s' % ('device', 'N', 'median', 'p90'))
for n, m in M.items():
    C, P, V = extract(load_clean(FILES[n]))
    sel = (P >= m.P_min) & (P <= m.P_max)
    C, P = C[sel], P[sel]
    idx = rng.choice(len(P), size=min(5000, len(P)), replace=False)
    e = []
    for i in idx:
        a = ri(m.signature(P[i])); b = ri(C[i] / C[i, 0])
        e.append(np.linalg.norm(a - b) / np.linalg.norm(b))
    print('%-16s %8d %9.1f%% %9.1f%%' % (n, len(idx), 100*np.median(e), 100*np.percentile(e, 90)))

print()
print('=== 2. 판별력: 고정 서명 vs s(p) ===')
L, P_ = M['laptop_charger'], M['minipc']
fixL = ri(np.mean([L.signature(p) for p in np.linspace(L.P_min, L.P_max, 40)], axis=0))
fixM = ri(np.mean([P_.signature(p) for p in np.linspace(P_.P_min, P_.P_max, 40)], axis=0))
print(' 고정 서명(전력 평균) 두 기기 각도       : %.2f deg' % ang(fixL, fixM))
print(' s(p): 겹치는 27W에서 두 기기 각도       : %.2f deg'
      % ang(ri(L.signature(27)), ri(P_.signature(27))))
print(' s(p): 충전기 자체 17W vs 69W 각도       : %.2f deg'
      % ang(ri(L.signature(17)), ri(L.signature(68))))
print(' s(p): 미니PC 자체 10W vs 27W 각도       : %.2f deg'
      % ang(ri(P_.signature(10)), ri(P_.signature(27))))

print()
print('=== 3. 혼합 분리 테스트 (합성 2기기, 격자 탐색) ===')
def solve(y, models, grids):
    best, arg = 1e18, None
    for pa in grids[0]:
        ia = models[0].current(pa, 220.0)
        for pb in grids[1]:
            r = np.linalg.norm(y - ia - models[1].current(pb, 220.0))
            if r < best:
                best, arg = r, (pa, pb)
    return arg

gL = np.arange(17, 69, 1.0); gM = np.arange(9.5, 27.1, 0.5)
truths = [(25, 12), (40, 20), (55, 10), (30, 25), (60, 26), (20, 15)]
noise_rel = 0.02
print('%-14s %-16s %-16s %s' % ('truth(W)', 's(p) 추정', '고정서명 추정', '오차 W (s(p) / 고정)'))
errs_sp, errs_fx = [], []
for pl, pm in truths:
    y = L.current(pl, 220.) + P_.current(pm, 220.)
    y = y + (rng.normal(0, noise_rel*abs(y).mean(), 15) + 1j*rng.normal(0, noise_rel*abs(y).mean(), 15))
    a, b = solve(y, [L, P_], [gL, gM])
    # 고정 서명 모델: 전력 평균 서명을 고정으로 사용
    class Fix:
        def __init__(s, base, vec): s.b, s.v = base, vec
        def current(s, p, v):
            r = s.b.current(p, v); return abs(r[0]) * s.v * np.exp(1j*np.angle(r[0]))
    fL = Fix(L, np.r_[1, fixL[:14] + 1j*fixL[14:]])
    fM = Fix(P_, np.r_[1, fixM[:14] + 1j*fixM[14:]])
    c, d = solve(y, [fL, fM], [gL, gM])
    e1 = (abs(a-pl)+abs(b-pm))/2; e2 = (abs(c-pl)+abs(d-pm))/2
    errs_sp.append(e1); errs_fx.append(e2)
    print('%-14s %-16s %-16s %.2f / %.2f' % ('%d + %d' % (pl, pm),
          '%.1f + %.1f' % (a, b), '%.1f + %.1f' % (c, d), e1, e2))
print('  평균 절대오차:  s(p) = %.2f W    고정서명 = %.2f W' % (np.mean(errs_sp), np.mean(errs_fx)))
