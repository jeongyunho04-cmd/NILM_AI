"""s(p) 곡선 피팅 — 측정 CSV -> 부하 의존 고조파 서명 모델(npz)"""
import numpy as np, pandas as pd, json, sys

IH  = ['ih%d'  % h for h in range(1, 16)]
DEG = ['ihdeg%d'% h for h in range(1, 16)]

def load_clean(files):
    ds = []
    for f in files:
        d = pd.read_csv(f)
        d = d[(d.pll_locked == 1) & (d.over_range == 0) & (d.cal_applied == 1)]
        ds.append(d)
    return pd.concat(ds, ignore_index=True)

def extract(d, p_min=0.5, stab_rel=0.02, stab_abs=0.3, win=11):
    A  = d[IH].values.astype(float)
    C  = A * np.exp(1j * np.deg2rad(d[DEG].values.astype(float)))
    P  = d.p_w.values.astype(float)
    V  = d.vrms.values.astype(float)
    thr = max(stab_abs, stab_rel * np.median(P[P > p_min]))
    st = (pd.Series(P).rolling(win, center=True).std() < thr).values
    ok = st & (P > p_min) & (A[:, 0] > 1e-3) & np.isfinite(P)
    return C[ok], P[ok], V[ok]

def bin_signatures(C, P, V, p_lo, p_hi, n_bins=12, min_n=60):
    """운전 구간을 로그 등간격으로 나눠 구간별 평균 복소 서명"""
    edges = np.geomspace(p_lo, p_hi, n_bins + 1)
    rows = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (P >= lo) & (P < hi)
        if m.sum() < min_n:
            continue
        c = C[m]
        rows.append(dict(P=P[m].mean(), V=V[m].mean(), N=int(m.sum()),
                         s=(c / c[:, :1]).mean(0),
                         i1=np.abs(c[:, 0]).mean(),
                         ph1=np.angle(c[:, 0].mean(), deg=True)))
    return rows


def standby_state(C, P, V, p_hi):
    """대기 상태 (연속 곡선과 분리)"""
    m = (P > 0.2) & (P < p_hi)
    if m.sum() < 60:
        return None
    c = C[m]
    return dict(P=P[m].mean(), V=V[m].mean(), N=int(m.sum()),
                s=(c / c[:, :1]).mean(0),
                i1=np.abs(c[:, 0]).mean(),
                ph1=np.angle(c[:, 0].mean(), deg=True))

def build_model(name, files, p_lo, p_hi, standby_hi=None,
                n_bins=12, min_n=60, discrete=False):
    d = load_clean(files)
    C, P, V = extract(d)
    rows = bin_signatures(C, P, V, p_lo, p_hi, n_bins, min_n)
    if len(rows) < 2:
        raise RuntimeError('%s: 유효 구간 부족 (%d)' % (name, len(rows)))
    sb = standby_state(C, P, V, standby_hi) if standby_hi else None
    Pg  = np.array([r['P']  for r in rows])
    S   = np.array([r['s']  for r in rows])
    i1  = np.array([r['i1'] for r in rows])
    ph1 = np.unwrap(np.deg2rad([r['ph1'] for r in rows]))
    Vg  = np.array([r['V']  for r in rows])
    Ng  = np.array([r['N']  for r in rows])
    k   = i1 * Vg / Pg
    m = dict(name=name, P=Pg, S=S, i1=i1, ph1_rad=ph1, V=Vg, N=Ng, k=k,
             discrete=discrete, V_ref=float(np.mean(Vg)),
             P_min=float(Pg.min()), P_max=float(Pg.max()))
    if sb:
        m.update(sb_P=sb['P'], sb_S=sb['s'], sb_i1=sb['i1'],
                 sb_ph1_rad=np.deg2rad(sb['ph1']), sb_N=sb['N'],
                 sb_k=sb['i1'] * sb['V'] / sb['P'])
    return m

def selfcheck(m, files):
    """피팅 곡선으로 원본 프레임을 재현했을 때의 상대 오차"""
    from sp_model import SPModel
    mm = SPModel.from_dict(m)
    d = load_clean(files); C, P, V = extract(d)
    idx = np.random.default_rng(0).choice(len(P), size=min(4000, len(P)), replace=False)
    err = []
    for i in idx:
        pred = mm.signature(P[i])
        a = np.r_[pred[1:].real, pred[1:].imag]
        t = (C[i] / C[i, 0])
        b = np.r_[t[1:].real, t[1:].imag]
        err.append(np.linalg.norm(a - b) / np.linalg.norm(b))
    return float(np.median(err)), float(np.percentile(err, 90))

if __name__ == '__main__':
    U = '/mnt/user-data/uploads/'
    specs = {
      'laptop_charger': dict(files=[U+'1788419936215_laptop_charger_1.csv',
                                    U+'1788419936214_laptop_charger_3_fixed.csv'],
                             p_lo=13.0, p_hi=72.0, standby_hi=5.0, n_bins=12),
      'minipc':         dict(files=[U+'1788419942496_minipc_2.csv',
                                    U+'1788419942496_minipc_3.csv'],
                             p_lo=7.5, p_hi=30.0, standby_hi=3.0, n_bins=10),
      'beam_projector': dict(files=[U+'1788419611621_beam_projector_1.csv',
                                    U+'1788419611621_beam_projector_2.csv'],
                             p_lo=44.0, p_hi=53.0, standby_hi=8.0, n_bins=3,
                             discrete=True),
    }
    out = {}
    for name, sp in specs.items():
        m = build_model(name, **sp)
        out[name] = m
        sbtxt = ('  standby %.2fW' % m['sb_P']) if 'sb_P' in m else ''
        print('%-16s K=%2d  P %5.1f-%5.1fW  V_ref=%.1f  k %.3f-%.3f%s' %
              (name, len(m['P']), m['P_min'], m['P_max'], m['V_ref'],
               m['k'].min(), m['k'].max(), sbtxt))
    arrs = {}
    for n, m in out.items():
        for key, v in m.items():
            if key == 'name':
                continue
            arrs[f'{n}__{key}'] = np.array(v)
    arrs['device_names'] = np.array(list(out.keys()))
    np.savez_compressed('/home/claude/sp/sp_curves.npz', **arrs)
    print('saved sp_curves.npz')
