"""
배경 부하(always-on) 모델 피팅
==============================
모든 라벨 기기가 OFF인 구간을 여러 측정 파일에서 모아, 배경 부하를
하나의 기기처럼 s(p) 곡선으로 만든다.

배경은 상수가 아니다. 실측에서 2.6~8.3 W 사이를 움직이고 서명도 함께 변한다.
상수 벡터로 두면 그 변동이 통째로 소형 기기(미니PC 등)의 추정 오차로 흡수된다.
실제로 이 성분을 넣은 것만으로 미니PC 검출률이 0.235 -> 0.575 로 올랐다.

사용:
    python fit_bg.py                          # sp_curves.npz -> sp_curves_v2.npz
    from fit_bg import fit_background_curve    # 다른 데이터셋에 재사용
"""
import numpy as np
import pandas as pd

IH  = ['ih%d'  % h for h in range(1, 16)]
DEG = ['ihdeg%d'% h for h in range(1, 16)]


def collect_off_frames(csv_path, off_mask_fn=None, p_off_max=8.0):
    """
    한 파일에서 '모든 기기 OFF' 프레임의 복소 고조파를 수집.

    off_mask_fn : (T) -> bool 배열. GT 구간 라벨이 있으면 그것을 쓰고,
                  없으면 p_w < p_off_max 로 대체한다.
    """
    d = pd.read_csv(csv_path)
    A = d[IH].values.astype(float)
    C = A * np.exp(1j * np.deg2rad(d[DEG].values.astype(float)))
    P = d.p_w.values.astype(float)
    V = d.vrms.values.astype(float)
    T = d.t_s.values.astype(float)
    good = (d.pll_locked.values == 1) & (d.over_range.values == 0)

    off = off_mask_fn(T) if off_mask_fn else (P < p_off_max)
    st = (pd.Series(P).rolling(11, center=True).std() < 0.5).values   # 전이 배제
    m = off & good & st & (A[:, 0] > 1e-4)
    return C[m], P[m], V[m]


def fit_background_curve(C, P, V, edges=None, min_n=80):
    """수집된 OFF 프레임 -> 전력 구간별 복소 서명 곡선"""
    if edges is None:
        edges = np.array([1.5, 3.0, 4.2, 5.2, 6.5, 9.0, 14.0])
    rows = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (P >= lo) & (P < hi)
        if m.sum() < min_n:
            continue
        c = C[m]
        rows.append(dict(P=P[m].mean(), V=V[m].mean(), N=int(m.sum()),
                         s=(c / c[:, :1]).mean(0),
                         i1=np.abs(c[:, 0]).mean(),
                         ph1=np.angle(c[:, 0].mean())))
    if len(rows) < 2:
        raise RuntimeError('배경 구간이 부족하다 (구간 %d개)' % len(rows))
    Pg = np.array([r['P'] for r in rows])
    Vg = np.array([r['V'] for r in rows])
    i1 = np.array([r['i1'] for r in rows])
    return dict(P=Pg, S=np.array([r['s'] for r in rows]), i1=i1,
                ph1_rad=np.unwrap([r['ph1'] for r in rows]), V=Vg,
                N=np.array([r['N'] for r in rows]), k=i1 * Vg / Pg,
                V_ref=float(Vg.mean()), discrete=False,
                P_min=float(Pg.min()), P_max=float(Pg.max()))


def merge_into(npz_in, npz_out, bg, name='background'):
    """기존 npz 에 성분 하나를 추가해 저장"""
    z = dict(np.load(npz_in, allow_pickle=False))
    for key, v in bg.items():
        z[name + '__' + key] = np.array(v)
    z['device_names'] = np.array([n for n in z['device_names'] if n != name] + [name])
    np.savez_compressed(npz_out, **z)
    return npz_out


if __name__ == '__main__':
    import json
    U = '/mnt/user-data/uploads/'
    GT = json.load(open(U + '1788423985364_real_events_refined.json'))['files']
    SRC = {                       # test_13 은 홀드아웃 검증용이라 제외한다
        'test_8':  U + 'test_8.csv',
        'test_9':  U + '1788425064074_test_9.csv',
        'test_10': U + '1788425064075_test_10.csv',
        'test_11': U + '1788425064075_test_11.csv',
        'test_12': U + '1788425064075_test_12.csv',
    }

    def mk_off(tag):
        if tag not in GT:
            return None
        def f(T):
            on = np.zeros(len(T), bool)
            for a, v in GT[tag]['intervals'].items():
                for lo, hi in v['on'] + v['uncertain']:
                    on[(T >= lo) & (T <= hi)] = True
            return ~on
        return f

    Cs, Ps, Vs = [], [], []
    for tag, path in SRC.items():
        c, p, v = collect_off_frames(path, mk_off(tag))
        if len(p) < 200:
            print('%-9s 건너뜀 (N=%d)' % (tag, len(p))); continue
        Cs.append(c); Ps.append(p); Vs.append(v)
        print('%-9s N=%5d  P=%.2f W' % (tag, len(p), p.mean()))

    C = np.vstack(Cs); P = np.concatenate(Ps); V = np.concatenate(Vs)
    bg = fit_background_curve(C, P, V)
    print()
    print('%8s %7s %9s %8s %8s' % ('P(W)', 'N', 'h3/h1', 'THD', 'k'))
    for i in range(len(bg['P'])):
        s = bg['S'][i]
        print('%8.2f %7d %9.4f %8.3f %8.3f'
              % (bg['P'][i], bg['N'][i], abs(s[2]),
                 np.sqrt(np.sum(np.abs(s[1:]) ** 2)), bg['k'][i]))
    print('\n저장:', merge_into('sp_curves.npz', 'sp_curves_v2.npz', bg))
