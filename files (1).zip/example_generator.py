"""생성기 통합 예시 — 고정 주입을 s(p) + 배경 성분으로 교체하는 최소 패턴"""
import numpy as np
from sp_model import SPModel

M = SPModel.load('sp_curves_v2.npz')
BG = M['background']

def synth_frame(active_powers, vrms=220.0, bg_w=None, legacy_sig=None, rng=None):
    """
    active_powers : {'laptop_charger': 45.0, 'minipc': 18.0, ...}
    bg_w          : 배경 부하 전력(W). None 이면 2.6~8.3 W 에서 무작위 추출
    legacy_sig    : {name: (15,) complex}  s(p) 곡선이 없는 기기용 고정 서명
    returns       : (15,) complex 총 전류 고조파
    """
    rng = rng or np.random.default_rng()
    if bg_w is None:
        bg_w = rng.uniform(BG.P_min, BG.P_max)
    I = BG.current(bg_w, vrms)                       # 배경은 항상 존재
    for name, p in active_powers.items():
        if p <= 0 or name == 'background':
            continue
        if name in M:
            I = I + M[name].current(p, vrms)         # 부하 의존
        elif legacy_sig and name in legacy_sig:
            s = legacy_sig[name]
            I = I + s * (p / vrms) / max(abs(s[0]), 1e-9)
    return I


if __name__ == '__main__':
    rng = np.random.default_rng(0)
    print('--- 합성 프레임 예시 (배경 포함) ---')
    for combo in [dict(laptop_charger=45.0, minipc=18.0),
                  dict(laptop_charger=25.0, minipc=25.0),
                  dict(laptop_charger=60.0, minipc=10.0, beam_projector=48.7)]:
        I = synth_frame(combo, 220.0, bg_w=5.0)
        thd = np.sqrt(np.sum(np.abs(I[1:]) ** 2)) / abs(I[0])
        print('%-58s |I1|=%.4fA  THD=%.3f' % (combo, abs(I[0]), thd))

    print()
    print('--- 배경 성분의 크기감 (미니PC 와 비교) ---')
    for w in [2.6, 5.0, 8.3]:
        print('  background %4.1fW : |I1|=%.4fA  THD=%.3f  k=%.2f'
              % (w, abs(BG.current(w, 220.)[0]), BG.thd(w), float(BG._k(w)[0])))
    for w in [9.5, 18.0, 27.0]:
        print('  minipc     %4.1fW : |I1|=%.4fA  THD=%.3f'
              % (w, abs(M['minipc'].current(w, 220.)[0]), M['minipc'].thd(w)))

    print()
    print('--- s(p): 부하에 따라 서명이 움직인다 ---')
    lc = M['laptop_charger']
    for p in [20, 35, 50, 65]:
        s = lc.signature(p)
        print(' laptop %2dW : THD=%.3f  h3/h1=%.4f  h5/h1=%.4f  h7/h1=%.4f'
              % (p, lc.thd(p), abs(s[2]), abs(s[4]), abs(s[6])))
