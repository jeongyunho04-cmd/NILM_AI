"""
부하 의존 고조파 서명 모델 s(p)
=================================
고정 서명(기기당 벡터 1개) 대신, 전력 p의 함수로 서명을 돌려준다.

핵심 API
    m = SPModel.load('sp_curves.npz')['laptop_charger']
    s = m.signature(45.0)              # (15,) complex, s[0]=1+0j  (h1 정규화)
    I = m.current(45.0, vrms=220.0)    # (15,) complex, 실제 암페어 (전압 기준 위상)
"""
import numpy as np

try:
    from scipy.interpolate import PchipInterpolator as _Interp
    _HAS_SCIPY = True
except ImportError:
    _HAS_SCIPY = False


def _make_interp(x, y):
    """단조 보존 보간. scipy 없으면 선형으로 폴백. 범위 밖은 끝값 고정."""
    x = np.asarray(x, float); y = np.asarray(y, float)
    if len(x) < 2:
        return lambda q: np.full_like(np.atleast_1d(q), y[0], dtype=float)
    if _HAS_SCIPY and len(x) >= 3:
        f = _Interp(x, y, extrapolate=False)
        def g(q):
            q = np.atleast_1d(np.asarray(q, float))
            r = f(np.clip(q, x[0], x[-1]))
            return r
        return g
    return lambda q: np.interp(np.clip(np.atleast_1d(q), x[0], x[-1]), x, y)


class SPModel:
    """기기 1종의 s(p) 곡선."""

    def __init__(self, name, P, S, i1, ph1_rad, k, V_ref,
                 discrete=False, N=None, standby=None):
        o = np.argsort(P)
        self.name = name
        self.P    = np.asarray(P, float)[o]
        self.S    = np.asarray(S)[o]          # (K,15) complex, S[:,0]==1
        self.i1   = np.asarray(i1, float)[o]
        self.ph1  = np.asarray(ph1_rad, float)[o]
        self.k    = np.asarray(k, float)[o]
        self.N    = None if N is None else np.asarray(N)[o]
        self.V_ref = float(V_ref)
        self.discrete = bool(discrete)
        self.standby = standby      # dict(P,S,k,ph1_rad) 또는 None
        self.P_min, self.P_max = float(self.P[0]), float(self.P[-1])
        # 고조파별 실/허수 보간기
        self._re = [_make_interp(self.P, self.S[:, h].real) for h in range(15)]
        self._im = [_make_interp(self.P, self.S[:, h].imag) for h in range(15)]
        self._k  = _make_interp(self.P, self.k)
        self._ph = _make_interp(self.P, self.ph1)

    # ---------- 생성 ----------
    def signature(self, p):
        """h1 정규화 복소 서명 (15,). s[0] = 1+0j."""
        if self.standby is not None and p < self.P_min * 0.6:
            return self.standby['S'].copy()
        if self.discrete:
            j = int(np.argmin(np.abs(self.P - float(p))))
            return self.S[j].copy()
        p = float(np.clip(p, self.P_min, self.P_max))
        s = np.array([self._re[h](p)[0] + 1j * self._im[h](p)[0] for h in range(15)])
        s[0] = 1.0 + 0j
        return s

    def current(self, p, vrms=None):
        """
        실제 전류 고조파 (15,) complex, 단위 A, 전압 기본파 기준 위상.
        |I1| = k(p) * p / vrms 로 스케일한다.
        """
        if p <= 0:
            return np.zeros(15, complex)
        v = self.V_ref if vrms is None else float(vrms)
        if self.standby is not None and p < self.P_min * 0.6:
            k, ph = self.standby['k'], self.standby['ph1_rad']
            return self.standby['S'] * (k * p / v) * np.exp(1j * ph)
        pc = float(np.clip(p, self.P_min, self.P_max))
        k  = float(self._k(pc)[0])
        ph = float(self._ph(pc)[0])
        i1 = k * p / v
        return self.signature(pc) * i1 * np.exp(1j * ph)

    def in_range(self, p):
        return self.P_min <= p <= self.P_max

    # ---------- 진단 ----------
    def thd(self, p):
        s = self.signature(p)
        return float(np.sqrt(np.sum(np.abs(s[1:]) ** 2)))

    def jacobian(self, p, dp=None):
        """d(p*s)/dp — 궤적 접선. 판별력 진단용. (15,) complex"""
        dp = dp if dp else max(0.25, 0.01 * p)
        a, b = np.clip([p - dp, p + dp], self.P_min, self.P_max)
        return ((b * self.signature(b)) - (a * self.signature(a))) / (b - a)

    # ---------- 직렬화 ----------
    def to_dict(self):
        return dict(name=self.name, P=self.P, S=self.S, i1=self.i1,
                    ph1_rad=self.ph1, k=self.k, V_ref=self.V_ref,
                    discrete=self.discrete, N=self.N)

    @classmethod
    def from_dict(cls, d):
        return cls(d.get('name', '?'), d['P'], d['S'], d['i1'],
                   d['ph1_rad'], d['k'], d['V_ref'],
                   d.get('discrete', False), d.get('N'), d.get('standby'))

    @staticmethod
    def load(path):
        z = np.load(path, allow_pickle=False)
        names = [str(x) for x in z['device_names']]
        out = {}
        for n in names:
            g = lambda key: z[f'{n}__{key}']
            sb = None
            if f'{n}__sb_S' in z:
                sb = dict(P=float(g('sb_P')), S=g('sb_S'), k=float(g('sb_k')),
                          ph1_rad=float(g('sb_ph1_rad')))
            out[n] = SPModel(n, g('P'), g('S'), g('i1'), g('ph1_rad'),
                             g('k'), float(g('V_ref')),
                             bool(g('discrete')), g('N'), sb)
        return out

    def __repr__(self):
        return (f'<SPModel {self.name} K={len(self.P)} '
                f'P={self.P_min:.1f}-{self.P_max:.1f}W '
                f'{"discrete" if self.discrete else "continuous"}>')


def mix(models_powers, vrms=220.0):
    """
    여러 기기의 합성 전류 고조파. KCL에 의해 복소 스펙트럼 중첩은 정확하다.
        models_powers: [(SPModel, power_W), ...]
    """
    tot = np.zeros(15, complex)
    for m, p in models_powers:
        tot += m.current(p, vrms)
    return tot
